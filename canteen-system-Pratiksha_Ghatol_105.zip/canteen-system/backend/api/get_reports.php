<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if user is logged in and is admin
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(array("message" => "Access denied. Admin privileges required."));
    exit();
}

try {
    // Today's sales
    $query = "SELECT COUNT(*) as total_orders, 
                     COALESCE(SUM(total_amount), 0) as total_revenue,
                     AVG(total_amount) as avg_order_value
              FROM orders 
              WHERE DATE(order_date) = CURDATE() AND status != 'cancelled'";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $today_stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // Monthly sales
    $query = "SELECT COUNT(*) as total_orders, 
                     COALESCE(SUM(total_amount), 0) as total_revenue
              FROM orders 
              WHERE MONTH(order_date) = MONTH(CURDATE()) 
              AND YEAR(order_date) = YEAR(CURDATE()) 
              AND status != 'cancelled'";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $monthly_stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // Popular items
    $query = "SELECT mi.item_name, 
                     SUM(oi.quantity) as total_quantity,
                     COUNT(DISTINCT oi.order_id) as order_count
              FROM order_items oi
              JOIN menu_items mi ON oi.item_id = mi.item_id
              JOIN orders o ON oi.order_id = o.order_id
              WHERE o.status != 'cancelled'
              GROUP BY mi.item_id
              ORDER BY total_quantity DESC
              LIMIT 10";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $popular_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Order status distribution
    $query = "SELECT status, COUNT(*) as count 
              FROM orders 
              WHERE DATE(order_date) = CURDATE()
              GROUP BY status";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $status_distribution = $stmt->fetchAll(PDO::FETCH_ASSOC);

    http_response_code(200);
    echo json_encode(array(
        "message" => "Reports retrieved successfully.",
        "reports" => array(
            "today" => array(
                "total_orders" => (int)$today_stats['total_orders'],
                "total_revenue" => (float)$today_stats['total_revenue'],
                "avg_order_value" => (float)$today_stats['avg_order_value']
            ),
            "monthly" => array(
                "total_orders" => (int)$monthly_stats['total_orders'],
                "total_revenue" => (float)$monthly_stats['total_revenue']
            ),
            "popular_items" => $popular_items,
            "status_distribution" => $status_distribution
        )
    ));
    
} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(array("message" => "Unable to generate reports."));
}
?>