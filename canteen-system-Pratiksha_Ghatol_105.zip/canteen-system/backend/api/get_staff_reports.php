<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if user is logged in and is staff
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'staff') {
    http_response_code(403);
    echo json_encode(array("message" => "Access denied. Staff privileges required."));
    exit();
}

try {
    // Today's order status distribution
    $query = "SELECT status, COUNT(*) as count 
              FROM orders 
              WHERE DATE(order_date) = CURDATE()
              GROUP BY status";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $status_distribution = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Popular items today
    $query = "SELECT mi.item_name, 
                     SUM(oi.quantity) as total_quantity,
                     COUNT(DISTINCT oi.order_id) as order_count
              FROM order_items oi
              JOIN menu_items mi ON oi.item_id = mi.item_id
              JOIN orders o ON oi.order_id = o.order_id
              WHERE DATE(o.order_date) = CURDATE() AND o.status != 'cancelled'
              GROUP BY mi.item_id
              ORDER BY total_quantity DESC
              LIMIT 5";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $popular_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Hourly order distribution today
    $query = "SELECT HOUR(order_date) as hour, COUNT(*) as order_count
              FROM orders 
              WHERE DATE(order_date) = CURDATE()
              GROUP BY HOUR(order_date)
              ORDER BY hour";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $hourly_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    http_response_code(200);
    echo json_encode(array(
        "message" => "Staff reports retrieved successfully.",
        "reports" => array(
            "status_distribution" => $status_distribution,
            "popular_items" => $popular_items,
            "hourly_orders" => $hourly_orders
        )
    ));
    
} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(array("message" => "Unable to retrieve staff reports."));
}
?>