<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if user is logged in
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(array("message" => "Please login first."));
    exit();
}

if(!isset($_GET['order_id'])) {
    http_response_code(400);
    echo json_encode(array("message" => "Order ID is required."));
    exit();
}

$order_id = $_GET['order_id'];
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

try {
    // Build query based on user role
    if($role === 'admin' || $role === 'staff') {
        // Staff/Admin can see any order
        $query = "SELECT o.*, u.username, u.email 
                  FROM orders o 
                  JOIN users u ON o.user_id = u.user_id 
                  WHERE o.order_id = ?";
        $params = [$order_id];
    } else {
        // Students can only see their own orders
        $query = "SELECT o.*, u.username, u.email 
                  FROM orders o 
                  JOIN users u ON o.user_id = u.user_id 
                  WHERE o.order_id = ? AND o.user_id = ?";
        $params = [$order_id, $user_id];
    }
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    
    if($stmt->rowCount() == 0) {
        http_response_code(404);
        echo json_encode(array("message" => "Order not found."));
        exit();
    }
    
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get order items
    $query = "SELECT oi.*, mi.item_name 
              FROM order_items oi 
              JOIN menu_items mi ON oi.item_id = mi.item_id 
              WHERE oi.order_id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$order_id]);
    
    $order_items = array();
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $order_items[] = array(
            "item_name" => $row['item_name'],
            "quantity" => $row['quantity'],
            "price" => (float)$row['price_at_time'],
            "subtotal" => (float)($row['quantity'] * $row['price_at_time'])
        );
    }
    
    // Get payment details
    $query = "SELECT * FROM payments WHERE order_id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$order_id]);
    $payment = $stmt->fetch(PDO::FETCH_ASSOC);
    
    http_response_code(200);
    echo json_encode(array(
        "message" => "Order details retrieved successfully.",
        "order" => array(
            "order_id" => $order['order_id'],
            "order_number" => 'ORD' . str_pad($order['order_id'], 3, '0', STR_PAD_LEFT),
            "user_name" => $order['username'],
            "user_email" => $order['email'],
            "total_amount" => (float)$order['total_amount'],
            "status" => $order['status'],
            "order_date" => $order['order_date'],
            "pickup_time" => date('h:i A', strtotime($order['pickup_time'])),
            "items" => $order_items,
            "payment" => array(
                "method" => $payment['payment_method'],
                "status" => $payment['payment_status'],
                "amount" => (float)$payment['amount'],
                "payment_date" => $payment['payment_date']
            )
        )
    ));
    
} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(array("message" => "Unable to retrieve order details."));
}
?>