<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if user is logged in
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(array("message" => "Please login first."));
    exit();
}

try {
    $query = "SELECT mi.*, c.category_name 
              FROM menu_items mi 
              JOIN categories c ON mi.category_id = c.category_id 
              WHERE mi.is_available = 1 
              ORDER BY c.category_name, mi.item_name";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $menu_items = array();
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $menu_item = array(
            "id" => $row['item_id'],
            "name" => $row['item_name'],
            "description" => $row['description'],
            "price" => (float)$row['price'],
            "category" => strtolower($row['category_name']),
            "image_url" => $row['image_url']
        );
        array_push($menu_items, $menu_item);
    }
    
    http_response_code(200);
    echo json_encode(array(
        "message" => "Menu items retrieved successfully.",
        "menu_items" => $menu_items
    ));
    
} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(array("message" => "Unable to retrieve menu items."));
}
?>