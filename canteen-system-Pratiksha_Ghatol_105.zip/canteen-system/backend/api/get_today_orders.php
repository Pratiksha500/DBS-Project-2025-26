<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if user is logged in and is staff/admin
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || ($_SESSION['role'] !== 'staff' && $_SESSION['role'] !== 'admin')) {
    http_response_code(403);
    echo json_encode(array("message" => "Access denied. Staff/Admin privileges required."));
    exit();
}

try {
    // Today's active orders count
    $query = "SELECT COUNT(*) as active_orders FROM orders WHERE DATE(order_date) = CURDATE() AND status IN ('pending', 'confirmed', 'preparing', 'ready')";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $active_orders = $stmt->fetch(PDO::FETCH_ASSOC);

    // Today's completed orders count
    $query = "SELECT COUNT(*) as completed_orders FROM orders WHERE DATE(order_date) = CURDATE() AND status = 'completed'";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $completed_orders = $stmt->fetch(PDO::FETCH_ASSOC);

    // Today's revenue
    $query = "SELECT COALESCE(SUM(total_amount), 0) as today_revenue FROM orders WHERE DATE(order_date) = CURDATE() AND status = 'completed'";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $revenue = $stmt->fetch(PDO::FETCH_ASSOC);

    // Orders needing attention (pending/confirmed)
    $query = "SELECT COUNT(*) as attention_orders FROM orders WHERE DATE(order_date) = CURDATE() AND status IN ('pending', 'confirmed')";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $attention_orders = $stmt->fetch(PDO::FETCH_ASSOC);

    http_response_code(200);
    echo json_encode(array(
        "message" => "Today's orders summary retrieved successfully.",
        "summary" => array(
            "active_orders" => (int)$active_orders['active_orders'],
            "completed_orders" => (int)$completed_orders['completed_orders'],
            "attention_orders" => (int)$attention_orders['attention_orders'],
            "today_revenue" => (float)$revenue['today_revenue']
        )
    ));
    
} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(array("message" => "Unable to retrieve today's orders summary."));
}
?>