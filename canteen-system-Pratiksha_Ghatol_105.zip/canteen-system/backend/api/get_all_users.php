<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if user is logged in and is admin
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(array("message" => "Access denied. Admin privileges required."));
    exit();
}

try {
    $query = "SELECT user_id, username, email, role, created_at FROM users ORDER BY created_at DESC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $users = array();
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $user = array(
            "user_id" => $row['user_id'],
            "username" => $row['username'],
            "email" => $row['email'],
            "role" => $row['role'],
            "created_at" => $row['created_at']
        );
        array_push($users, $user);
    }
    
    http_response_code(200);
    echo json_encode(array(
        "message" => "Users retrieved successfully.",
        "users" => $users
    ));
    
} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(array("message" => "Unable to retrieve users."));
}
?>