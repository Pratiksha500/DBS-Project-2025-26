<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if user is logged in
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(array("message" => "Please login first."));
    exit();
}

$data = json_decode(file_get_contents("php://input"));

if(
    !empty($data->order_data) &&
    !empty($data->payment_method)
) {
    try {
        $db->beginTransaction();
        
        $order_data = $data->order_data;
        $user_id = $_SESSION['user_id'];
        
        // Insert order
        $query = "INSERT INTO orders SET user_id=?, total_amount=?, pickup_time=?, status='confirmed'";
        $stmt = $db->prepare($query);
        $pickup_datetime = DateTime::createFromFormat('h:i A', $order_data->pickup_time);
        $pickup_datetime_str = $pickup_datetime->format('Y-m-d H:i:s');
        $stmt->execute([$user_id, $order_data->final_total, $pickup_datetime_str]);
        $order_id = $db->lastInsertId();
        
        // Insert order items
        $query = "INSERT INTO order_items (order_id, item_id, quantity, price_at_time) VALUES (?, ?, ?, ?)";
        $stmt = $db->prepare($query);
        
        foreach($order_data->cart as $item) {
            $stmt->execute([$order_id, $item->id, $item->quantity, $item->price]);
        }
        
        // Insert payment record
        $query = "INSERT INTO payments (order_id, amount, payment_method, payment_status) VALUES (?, ?, ?, 'completed')";
        $stmt = $db->prepare($query);
        $stmt->execute([$order_id, $order_data->final_total, $data->payment_method]);
        
        $db->commit();
        
        http_response_code(201);
        echo json_encode(array(
            "message" => "✅ Payment successful! Order placed.",
            "order_id" => $order_id
        ));
        
    } catch(PDOException $exception) {
        $db->rollBack();
        http_response_code(503);
        echo json_encode(array("message" => "❌ Payment failed. Please try again."));
    }
} else {
    http_response_code(400);
    echo json_encode(array("message" => "❌ Unable to process payment. Data is incomplete."));
}
?>