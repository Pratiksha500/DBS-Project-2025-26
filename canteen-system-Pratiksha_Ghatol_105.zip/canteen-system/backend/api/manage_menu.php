<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, PUT, DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if user is logged in and is admin
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(array("message" => "Access denied. Admin privileges required."));
    exit();
}

$data = json_decode(file_get_contents("php://input"));
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch($method) {
        case 'POST': // Add new menu item
            if(!empty($data->item_name) && !empty($data->price) && !empty($data->category_id)) {
                $query = "INSERT INTO menu_items SET category_id=?, item_name=?, description=?, price=?, image_url=?";
                $stmt = $db->prepare($query);
                
                $description = !empty($data->description) ? $data->description : '';
                $image_url = !empty($data->image_url) ? $data->image_url : '';
                
                if($stmt->execute([$data->category_id, $data->item_name, $description, $data->price, $image_url])) {
                    http_response_code(201);
                    echo json_encode(array("message" => "✅ Menu item added successfully!"));
                } else {
                    http_response_code(503);
                    echo json_encode(array("message" => "❌ Unable to add menu item."));
                }
            } else {
                http_response_code(400);
                echo json_encode(array("message" => "❌ Unable to add menu item. Required data is missing."));
            }
            break;

        case 'PUT': // Update menu item
            if(!empty($data->item_id) && !empty($data->item_name) && !empty($data->price) && !empty($data->category_id)) {
                $query = "UPDATE menu_items SET category_id=?, item_name=?, description=?, price=?, image_url=?, is_available=? WHERE item_id=?";
                $stmt = $db->prepare($query);
                
                $description = !empty($data->description) ? $data->description : '';
                $image_url = !empty($data->image_url) ? $data->image_url : '';
                $is_available = isset($data->is_available) ? $data->is_available : 1;
                
                if($stmt->execute([$data->category_id, $data->item_name, $description, $data->price, $image_url, $is_available, $data->item_id])) {
                    http_response_code(200);
                    echo json_encode(array("message" => "✅ Menu item updated successfully!"));
                } else {
                    http_response_code(503);
                    echo json_encode(array("message" => "❌ Unable to update menu item."));
                }
            } else {
                http_response_code(400);
                echo json_encode(array("message" => "❌ Unable to update menu item. Required data is missing."));
            }
            break;

        case 'DELETE': // Delete menu item
            if(!empty($data->item_id)) {
                $query = "DELETE FROM menu_items WHERE item_id = ?";
                $stmt = $db->prepare($query);
                
                if($stmt->execute([$data->item_id])) {
                    http_response_code(200);
                    echo json_encode(array("message" => "✅ Menu item deleted successfully!"));
                } else {
                    http_response_code(503);
                    echo json_encode(array("message" => "❌ Unable to delete menu item."));
                }
            } else {
                http_response_code(400);
                echo json_encode(array("message" => "❌ Unable to delete menu item. Item ID is required."));
            }
            break;

        default:
            http_response_code(405);
            echo json_encode(array("message" => "Method not allowed."));
            break;
    }
} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(array("message" => "❌ Database error: " . $exception->getMessage()));
}
?>