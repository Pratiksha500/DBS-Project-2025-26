<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if user is logged in and is admin
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(array("message" => "Access denied. Admin privileges required."));
    exit();
}

$data = json_decode(file_get_contents("php://input"));

if(!empty($data->user_id) && !empty($data->role)) {
    // Validate role
    $allowed_roles = ['admin', 'staff', 'student'];
    if(!in_array($data->role, $allowed_roles)) {
        http_response_code(400);
        echo json_encode(array("message" => "❌ Invalid role specified."));
        exit();
    }

    // Prevent admin from changing their own role
    if($data->user_id == $_SESSION['user_id'] && $data->role != 'admin') {
        http_response_code(400);
        echo json_encode(array("message" => "❌ You cannot change your own admin role."));
        exit();
    }

    try {
        $query = "UPDATE users SET role = ? WHERE user_id = ?";
        $stmt = $db->prepare($query);
        
        if($stmt->execute([$data->role, $data->user_id])) {
            http_response_code(200);
            echo json_encode(array("message" => "✅ User role updated successfully!"));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "❌ Unable to update user role."));
        }
    } catch(PDOException $exception) {
        http_response_code(500);
        echo json_encode(array("message" => "❌ Database error: " . $exception->getMessage()));
    }
} else {
    http_response_code(400);
    echo json_encode(array("message" => "❌ Unable to update user. Required data is missing."));
}
?>