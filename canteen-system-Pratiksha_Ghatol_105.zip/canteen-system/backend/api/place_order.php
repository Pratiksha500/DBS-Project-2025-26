<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if user is logged in
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(array("message" => "Please login first."));
    exit();
}

$data = json_decode(file_get_contents("php://input"));

if(
    !empty($data->cart) &&
    !empty($data->total_amount) &&
    !empty($data->pickup_time)
) {
    // Validate pickup time constraints
    $pickup_time = DateTime::createFromFormat('h:i A', $data->pickup_time);
    $current_time = new DateTime();
    
    // College hours: 10:00 AM to 6:00 PM
    $college_start = DateTime::createFromFormat('H:i', '10:00');
    $college_end = DateTime::createFromFormat('H:i', '18:00');
    
    // 30 minutes preparation time
    $earliest_pickup = clone $current_time;
    $earliest_pickup->modify('+30 minutes');
    
    // Round up to nearest 30 minutes
    $minutes = $earliest_pickup->format('i');
    $rounded_minutes = ceil($minutes / 30) * 30;
    $earliest_pickup->setTime($earliest_pickup->format('H'), $rounded_minutes);
    
    // Validate constraints
    if($pickup_time->format('H:i') < $college_start->format('H:i') || 
       $pickup_time->format('H:i') > $college_end->format('H:i')) {
        http_response_code(400);
        echo json_encode(array("message" => "❌ Pickup time must be between 10:00 AM and 6:00 PM."));
        exit();
    }
    
    if($pickup_time < $earliest_pickup) {
        http_response_code(400);
        echo json_encode(array("message" => "❌ Pickup time must be at least 30 minutes from now. Earliest available: " . $earliest_pickup->format('h:i A')));
        exit();
    }
    
    if($pickup_time < $current_time) {
        http_response_code(400);
        echo json_encode(array("message" => "❌ Cannot select past time for pickup."));
        exit();
    }
    
    try {
        $db->beginTransaction();
        
        // Insert order
        $query = "INSERT INTO orders SET user_id=?, total_amount=?, pickup_time=?, status='pending'";
        $stmt = $db->prepare($query);
        $pickup_datetime = $pickup_time->format('Y-m-d H:i:s');
        $stmt->execute([$_SESSION['user_id'], $data->total_amount, $pickup_datetime]);
        $order_id = $db->lastInsertId();
        
        // Insert order items
        $query = "INSERT INTO order_items (order_id, item_id, quantity, price_at_time) VALUES (?, ?, ?, ?)";
        $stmt = $db->prepare($query);
        
        foreach($data->cart as $item) {
            $stmt->execute([$order_id, $item->id, $item->quantity, $item->price]);
        }
        
        $db->commit();
        
        http_response_code(201);
        echo json_encode(array(
            "message" => "✅ Order placed successfully!",
            "order_id" => $order_id,
            "pickup_time" => $data->pickup_time
        ));
        
    } catch(PDOException $exception) {
        $db->rollBack();
        http_response_code(503);
        echo json_encode(array("message" => "❌ Unable to place order."));
    }
} else {
    http_response_code(400);
    echo json_encode(array("message" => "❌ Unable to place order. Data is incomplete."));
}
?>