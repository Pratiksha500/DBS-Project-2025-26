<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Get POST data
$input = file_get_contents("php://input");
$data = json_decode($input);

// Debug log (remove in production)
error_log("Forgot Password Request: " . $input);

if(!empty($data) && !empty($data->email)) {
    
    // Check if email ends with @mgmcen.ac.in
    if(!preg_match('/@mgmcen\.ac\.in$/', $data->email)) {
        http_response_code(400);
        echo json_encode(array(
            "success" => false,
            "message" => "Only MGM college email addresses (@mgmcen.ac.in) are allowed."
        ));
        exit();
    }

    try {
        // Check if user exists
        $query = "SELECT user_id, username FROM users WHERE email = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$data->email]);
        
        if($stmt->rowCount() > 0) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // In a real application, you would:
            // 1. Generate a unique reset token
            // 2. Save it to database with expiration time  
            // 3. Send email with reset link
            
            // For demo purposes, we'll just return success
            http_response_code(200);
            echo json_encode(array(
                "success" => true,
                "message" => "Password reset instructions have been sent to your email. Please check your inbox. (Demo: In real system, email would be sent)"
            ));
        } else {
            http_response_code(404);
            echo json_encode(array(
                "success" => false,
                "message" => "No account found with this email address."
            ));
        }
        
    } catch(PDOException $exception) {
        http_response_code(500);
        echo json_encode(array(
            "success" => false,
            "message" => "Unable to process request. Please try again later."
        ));
    }
} else {
    http_response_code(400);
    echo json_encode(array(
        "success" => false,
        "message" => "❌ Email address is required.",
        "debug" => "Received data: " . $input
    ));
}
?>