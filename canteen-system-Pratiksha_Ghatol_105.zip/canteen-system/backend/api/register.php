<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents("php://input"));

if(
    !empty($data->username) &&
    !empty($data->email) &&
    !empty($data->password)
) {
    // Check if email ends with @mgmcen.ac.in
    if(!preg_match('/@mgmcen\.ac\.in$/', $data->email)) {
        http_response_code(400);
        echo json_encode(array("message" => "❌ Only college email addresses (@mgmcen.ac.in) are allowed."));
        exit();
    }

    // Check if user already exists
    $query = "SELECT user_id FROM users WHERE email = ? OR username = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$data->email, $data->username]);
    
    if($stmt->rowCount() > 0) {
        http_response_code(400);
        echo json_encode(array("message" => "❌ User already exists with this email or username."));
        exit();
    }

    // Insert new user
    $query = "INSERT INTO users SET username=?, email=?, password=?, role='student'";
    $stmt = $db->prepare($query);
    
    // Hash password
    $password_hash = password_hash($data->password, PASSWORD_DEFAULT);
    
    if($stmt->execute([$data->username, $data->email, $password_hash])) {
        http_response_code(201);
        echo json_encode(array("message" => "✅ User registered successfully!"));
    } else {
        http_response_code(503);
        echo json_encode(array("message" => "❌ Unable to register user."));
    }
} else {
    http_response_code(400);
    echo json_encode(array("message" => "❌ Unable to register user. Data is incomplete."));
}
?>