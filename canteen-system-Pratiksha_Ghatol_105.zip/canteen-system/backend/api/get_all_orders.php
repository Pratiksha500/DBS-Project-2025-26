<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if user is logged in and is admin/staff
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    http_response_code(403);
    echo json_encode(array("message" => "Access denied. Admin/Staff privileges required."));
    exit();
}

try {
    $query = "SELECT o.order_id, o.total_amount, o.status, o.order_date, o.pickup_time,
                     u.username, u.email, u.role as user_role,
                     GROUP_CONCAT(CONCAT(oi.quantity, 'x ', mi.item_name) SEPARATOR ', ') as items
              FROM orders o
              JOIN users u ON o.user_id = u.user_id
              JOIN order_items oi ON o.order_id = oi.order_id
              JOIN menu_items mi ON oi.item_id = mi.item_id
              GROUP BY o.order_id
              ORDER BY o.order_date DESC";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $orders = array();
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $order = array(
            "order_id" => $row['order_id'],
            "order_number" => 'ORD' . str_pad($row['order_id'], 3, '0', STR_PAD_LEFT),
            "username" => $row['username'],
            "email" => $row['email'],
            "user_role" => $row['user_role'],
            "items" => $row['items'],
            "total_amount" => (float)$row['total_amount'],
            "status" => $row['status'],
            "order_date" => $row['order_date'],
            "pickup_time" => date('h:i A', strtotime($row['pickup_time']))
        );
        array_push($orders, $order);
    }
    
    http_response_code(200);
    echo json_encode(array(
        "message" => "Orders retrieved successfully.",
        "orders" => $orders
    ));
    
} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(array("message" => "Unable to retrieve orders."));
}
?>