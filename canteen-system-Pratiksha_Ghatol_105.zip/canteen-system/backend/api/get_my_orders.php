<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Check if user is logged in
if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(array("message" => "Please login first."));
    exit();
}

try {
    $query = "SELECT o.order_id, o.total_amount, o.status, o.order_date, o.pickup_time,
                     GROUP_CONCAT(CONCAT(oi.quantity, 'x ', mi.item_name) SEPARATOR ', ') as items
              FROM orders o
              JOIN order_items oi ON o.order_id = oi.order_id
              JOIN menu_items mi ON oi.item_id = mi.item_id
              WHERE o.user_id = ?
              GROUP BY o.order_id
              ORDER BY o.order_date DESC
              LIMIT 10";
    
    $stmt = $db->prepare($query);
    $stmt->execute([$_SESSION['user_id']]);
    
    $orders = array();
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $order = array(
            "id" => 'ORD' . str_pad($row['order_id'], 3, '0', STR_PAD_LEFT),
            "order_id" => $row['order_id'],
            "items" => $row['items'],
            "total" => (float)$row['total_amount'],
            "status" => $row['status'],
            "order_date" => $row['order_date'],
            "pickup_time" => date('h:i A', strtotime($row['pickup_time']))
        );
        array_push($orders, $order);
    }
    
    http_response_code(200);
    echo json_encode(array(
        "message" => "Orders retrieved successfully.",
        "orders" => $orders
    ));
    
} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(array("message" => "Unable to retrieve orders."));
}
?>